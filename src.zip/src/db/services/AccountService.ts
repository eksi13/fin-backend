import { Account } from "../../classes/Account";
import { AccountData, InsertAccountData } from "../../models/AccountData";
import { AccountType, Currency } from "../../types";
import { AccountRepository } from "../repositories/AccountRepository";


// service layer, used for business logic
// interactions with transacitons

// create

// read
// get name, balance, type, currency

// update
// change name
// change balance
    // increase / decrease balance with transactions
    // transfer money from one to another
    // adjust balance
// change type
// change currency -> hole aktuellen umrechenkurs?

// crud?
// create, read, update, delete


// how do AccountData & AccountService interact?


export class AccountService {
    private repository: AccountRepository;    

    public constructor(repository: AccountRepository) {
        this.repository = repository;
    };

    // create
    public async createAccount(account: InsertAccountData): Promise<AccountData> {
        return await this.repository.createAccount(account);
    };


    // read
    // todo error handling
    public async getAccountById(id: number): Promise<AccountData> {
       return await this.repository.getAccountById(id);
    };

    public async getAllAccounts(): Promise<AccountData[]> {
        return this.repository.getAllAccounts();
    };


    // update
    public async transferBalance(fromAccount: Account, toAccount: Account, amount: number) {

    };

    public async adjustBalance(account: Account, amount: number) {

    };

    public async updateName(accountId: number, newName: string) {
        const newAccountData = 

    };

    public async updateAcountType(account: Account, newType: AccountType) {

    };

    public async updateCurrency(account: Account, newCurrency: Currency) {

    };

    
    // delete
    public async deleteAccount(account: Account) {

    };
    

    // helper methods

    private async checkIfExists(id: number): Promise<boolean> {
        const result = await this.repository.getAccountById(id);

        let flag = false;
        if (result) { flag = true };

        return flag;
    };

    private checkBalance(account: Account) {};



    // future
    /*
    - currency conversion service
    - format account summary
    - account error class in a seperate file AccountErrors.ts ??
    - archiving
    - account locking (what even is this?)
    */

};