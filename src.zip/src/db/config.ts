export var SCHEMA_FILES = {
    account_table: 'account_table.sql',
    transaction_table: 'transaction_table.sql',
    category_table: 'category_table.sql'
};